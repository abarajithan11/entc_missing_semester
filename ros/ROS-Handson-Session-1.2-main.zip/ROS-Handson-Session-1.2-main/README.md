# ROS-Handson-Session-1.2
Resources for hands-on session of Introduction to ROS Workshop
